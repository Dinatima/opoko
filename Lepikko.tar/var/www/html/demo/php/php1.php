<?php
echo "<table border>";
for ($i = 1; $i <= 40; $i++) {
    echo "<tr>";
    for ($j = 1; $j <= 40; $j++) {
        echo "<td>" . ($i * $j) . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>