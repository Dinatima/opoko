<?php
$viesti = $_POST["viesti"];
$maara = $_POST["maara"];
for ($i = 0; $i < $maara; $i++) {
    echo htmlspecialchars($viesti) . "<br>";
}
?>
