<?php
echo 'Hello ' . htmlspecialchars($_POST["name"]) . '!';
?>