<!DOCTYPE html>
<html lang="en">
<title>Google</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Heebo", sans-serif}
.mySlides {display: none}
</style>
<div class="w3-bottom">
  <div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="../demo5" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="band.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GIF</a>
    <a href="tour.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ANIMALS</a>
    <a href="contact.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GOOGLE</a>
	<a href=mallipohja.html class="w3-bar-item w3-button w3-padding-large w3-hide-small">MALLIPOHJA</a>

      </div>
    </div>

  </div>
</div>

<div class="w3-pink w3-content" style="max-width:2000px">
  <div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <img src="google.png" class="w3-center">
    <h2 class=" w3-center">Google search</h2>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom">
      </div>
      <div class="w3-center w3-col m6">
	  
          </div>
		  <form action="https://google.com/search" method="get">
		  <input type="hidden" name="sitesearch" />
          <input class="w3-cyan w3-input w3-border" type="text" placeholder="Google" name="q">
          <button class="w3-button w3-cyan w3-section w3-right" type="submit">SEND</button>
        </form>
      </div>
    </div>
  </div>
</div>
<footer>
<div class="w3-pink">
<h1 class="w3-center"> Human facts </h1>
<h3>Humans (Homo sapiens) are the only extant members of the subtribe Hominina. Together with chimpanzees, gorillas, and orangutans, they are part of the family Hominidae (the great apes, or hominids). A terrestrial animal, humans are characterized by their erect posture and bipedal locomotion; high manual dexterity and heavy tool use compared to other animals; open-ended and complex language use compared to other animal communications; larger, more complex brains than other animals; and highly advanced and organized societies.</h3>
<br><p>The spread of the large and increasing population of humans has profoundly affected much of the biosphere and millions of species worldwide. Advantages that explain this evolutionary success include a larger brain with a well-developed neocortex, prefrontal cortex and temporal lobes, which enable advanced abstract reasoning, language, problem solving, sociality, and culture through social learning. Humans use tools more and better than any other animal; and are the only extant species to build fires, cook food, clothe themselves, and create and use numerous other technologies and arts.</p></br>
<br><p>Most aspects of human physiology are closely homologous to corresponding aspects of animal physiology. The human body consists of the legs, the torso, the arms, the neck, and the head. An adult human body consists of about 100 trillion (1014) cells. The most commonly defined body systems in humans are the nervous, the cardiovascular, the circulatory, the digestive, the endocrine, the immune, the integumentary, the lymphatic, the musculoskeletal, the reproductive, the respiratory, and the urinary system.</p></br>
<br></br>
</div>
</footer> 