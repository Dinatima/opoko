<!DOCTYPE html>
<html lang="en">
<title>Animals</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Heebo", sans-serif}
.mySlides {display: none}
</style>
<body>
<div class="w3-bottom">
  <div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="../demo5" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="band.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GIF</a>
    <a href="tour.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ANIMALS</a>
    <a href="contact.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GOOGLE</a>
	<a href=mallipohja.html class="w3-bar-item w3-button w3-padding-large w3-hide-small">MALLIPOHJA</a>

      </div>
    </div>

  </div>
</div>

<div class="w3-content" style="max-width:2000px">
  <div class="w3-red" id="tour">
    <div class="w3-container w3-content w3-padding-64" style="max-width:800px">
      <h2 class=" w3-center w3-red">Kuvia</h2>
      <p class="w3-opacity w3-center"><i></i></p><br>


      <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
        <div class="w3-third w3-margin-bottom">
          <img src="katti.jpg" alt="New York" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-trueblack">
            <p><b>Hilma</b></p>
            <p class="w3-opacity">Maanantai</p>
            <p>Katti</p>
            <button class="w3-button w3-trueblack w3-margin-bottom" onclick="document.getElementById('ticketModal').style.display='block'">Osta</button>
          </div>
        </div>
        <div class="w3-third w3-margin-bottom">
          <img src="Koira.jpg" alt="Paris" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-trueblack">
            <p><b>Ursa</b></p>
            <p class="w3-opacity">Lauantai</p>
            <p>Koira</p>
            <button class="w3-button w3-trueblack w3-margin-bottom" onclick="document.getElementById('ticketModal').style.display='block'">Osta</button>
          </div>
        </div>
        <div class="w3-third w3-margin-bottom">
          <img src="delfiini.jpg" alt="San Francisco" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-trueblack">
            <p><b>Zhoco</b></p>
            <p class="w3-opacity">Tiistai</p>
            <p>Delfiini</p>
            <button class="w3-button w3-trueblack w3-margin-bottom" onclick="document.getElementById('ticketModal').style.display='block'">Osta</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<footer>
<img src="norsun.svg" style=w3-image>
<img src="norsun.svg" style=w3-image>
</footer>