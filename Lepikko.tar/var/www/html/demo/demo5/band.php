<!DOCTYPE html>
<html lang="en">
<title>Life cycle</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>body {
 background-image: url("1.gif");
 background-color: #cccccc;
 background-position: center;
 background-size: cover;
 font-family: "Heebo", sans-serif
}
</style>
<body>
<div class="w3-bottom">
  <div class="w3-bar w3-blue w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="../demo5" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="band.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GIF</a>
    <a href="tour.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ANIMALS</a>
    <a href="contact.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GOOGLE</a>
	<a href=mallipohja.html class="w3-bar-item w3-button w3-padding-large w3-hide-small">MALLIPOHJA</a>

      </div>
    </div>

  </div>
</div>

<div class="w3-content" style="max-width:2000px;margin-top:800px"> 
<p class="w3-pink">Life cycle</p>

</div>
</body>