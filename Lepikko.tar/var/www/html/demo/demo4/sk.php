<link href="style/style.css" media="screen" rel="stylesheet" title="main">
<div id="left">
     <div class="box">
          <ul>
               <li><a href="harrastukset.php">Harrastukset</a></li>
               <li><a href="yhteystiedot.php">Yhteystiedot </a></li>
               <li><a href="tiedotteet.php">Tiedotteet</a></li>
          </ul>
     </div>

     <div class="box">
     </div>
</div>