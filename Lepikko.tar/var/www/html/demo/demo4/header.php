<link href="style/style.css" media="screen" rel="stylesheet" title="main">
<div id="header">
     <h1>Sivusto - Pyry Lepikko</h1>
</div>