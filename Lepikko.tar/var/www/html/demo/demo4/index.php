<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Etusivu</title>
<link href="style/style.css" media="screen" rel="stylesheet" title="main">
</head>
<body>

<?php include 'header.php';?>


<div id="right">
     <div id="content">
          <img src="kuvat/kuva1.jpg">	
     </div>
</div>


<?php include 'harrastukset.php';
include 'yhteystiedot.php';
include 'tiedotteet.php';
?>
<div id="footer">
     <p>Pyry Lepikko 17.1.2019</p>
</div>

</body>
</html>